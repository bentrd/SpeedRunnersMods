-- set ghosts demo
-- sets the current map's top 5 runs as ghosts

COUNT = 5
mapId = get("Velo.mapId")
requestId = requestMapCategoryRuns(mapId, NEW_LAP, 0, 0, COUNT)

for i = 0, COUNT - 1 do
    prepareGhost(i)
end

onReceiveRuns = function(requestId_, runs)
    if requestId_ == requestId then
        for i, run in ipairs(runs) do
            download(run.id, "_temp" .. tostring(i))
        end
    end
end

nextGhostIndex = 0

onDownloadFinished = function(requestId, id, name)
    setGhost(name, nextGhostIndex)
    deleteRec(name)
    nextGhostIndex = nextGhostIndex + 1

    if nextGhostIndex == COUNT then
        exit()
    end
end