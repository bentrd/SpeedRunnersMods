-- Speedometer demo
-- Simple reimplementation of the speedometer as a LUA-script

-- time in seconds until the next refresh
refreshTimer = 0

-- the speed to display
speed = 0

-- toggleable via F3
enabled = true

-- gets called after all the game's draw functions have been called
onPostDraw = function()
    if isPressed(0x72) then -- F3 key code
        enabled = not enabled
    end

    if not enabled then
        return
    end

    -- prevent errors
    if not get("Velo.isIngame") then
        return;
    end

    -- increment timer
    refreshTimer = refreshTimer - get("Velo.realDeltaSec")
    if refreshTimer <= 0 then
        speed = Vector2:length(get("Player.actor.velocity"))
        refreshTimer = 0.1
    end

    local position = get("Player.actor.position")
    local offset = Vector2:new(12.5, -120)

    -- transform coordinates from world coordinates to screen coordinates
    local screenCoords = worldToScreen(position + offset)

     -- make sure to scale properly depending on the zoom level
    local scale = 1 / get("CCamera.zoom")

    local r = math.min(speed / 1500, 1)

    drawText(
        tostring(math.floor((speed + 2.5) / 5) * 5), -- the text to draw
        screenCoords,
        Vector2:new(), -- bounding box size (let's just keep it at zero)
        Vector2:new(0.5, 0), -- alignment (let's center it horizontally)
        scale,
        -0.05, -- rotation
        "UI\\Font\\Souses.ttf", 24,
        true, -- drop a shadow
        Color:mix(Color:new(0, 200, 200), Color:new(180, 0, 0), r) -- color
    )
end