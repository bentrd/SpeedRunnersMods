-- rotating gravity demo
-- Rotates gravity's direction around for absolute confusion
-- Try making it through a whole lap

-- usage: `rotateGravity [rotationSpeed]` (degrees per second)

angle = 0
direction = Vector2:new(1, 0)
rotationSpeed = arg[1]

-- gets called before the game's update function gets called
onPreUpdate = function()
    -- prevent errors
    if not get("Velo.isIngame") or get("Velo.isOnline") then
        return;
    end

    local delta = get("Velo.realDeltaSec") -- `Velo.realDeltaSec` returns the elapsed time since the previous update in seconds
    angle = angle + rotationSpeed * delta

    local angleRad = math.rad(angle)
    direction = Vector2:new(math.cos(angleRad), math.sin(angleRad))

    setSt("Offline_Game_Mods.physics.gravity", 1000 * direction)
end

onPostDraw = function()
    if not get("Velo.isIngame") or get("Velo.isOnline") then
        return;
    end

    local offset = Vector2:new(12.5, 22.5)
    local position = get("Player.actor.position") + offset

    -- transform coordinates from world coordinates to screen coordinates
    local p1 = worldToScreen(position)
    local p2 = worldToScreen(position + 100 * direction)

    drawLine(
        p1, p2,
        3,
        Color:new(0, 180, 0)
    )
end

-- gets called when the script gets stopped
onStop = function()
    defaultSt("Offline_Game_Mods.physics.gravity")
end