-- auto spam grapples demo
-- Automatically spam grapple just by holding the 'V' key
-- task: Improve this demo to make it work better

-- gets called right after the player's inputs got polled and set
onSetInputs = function(playerIndex)
    if isUp(0x56) then -- V key code
        return
    end

    -- prevent errors
    if not get("Velo.isIngame") or get("Velo.isOnline") then
        return;
    end

    canGrapple = get("Player.canGrapple")
    swinging = get("Player.isSwinging")
    swingAngle = get("Player.swingAngle")
    moveDir = get("Player.moveDirection")

    grappleHeld = canGrapple -- grapple whenever possible
    jumpHeld = not swinging

    if 
        swinging and 
        ((moveDir == 1 and swingAngle <= math.rad(90)) or 
        (moveDir == -1 and swingAngle >= math.rad(90))) 
    then
        grappleHeld = false -- release on reaching 90 degrees
    end

    set("Player.isGrappleHeld", grappleHeld)
    set("Player.isJumpHeld", jumpHeld)
end