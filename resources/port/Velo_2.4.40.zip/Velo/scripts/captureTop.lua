-- capture top 3 demo
-- captures the current map's top 3 runs into a single video

-- change to NEW_LAP, ONE_LAP, NEW_LAP_SKIP or ONE_LAP_SKIP
CATEGORY = NEW_LAP

-- video settings
EXTRA_SECONDS = 1
CRF = 18
PRESET = 0
BATCH_SIZE = 100
BATCH_COUNT = 3
CAPTURE_AUDIO = true
MERGE_AUDIO_TO_VIDEO = true

-- ghost settings
GHOST_OPACITY = 1
GHOST_DISABLE_GRAPPLES = true
GHOST_VARIANTS = { 0, 2 }

-- info text style
TOP_COLORS = { 
    Color:new(255, 215, 0), 
    Color:new(192, 192, 192), 
    Color:new(206, 137, 70) 
}
INFO_TEXT_DURATION = 5
INFO_TEXT_OFFSET = 30
INFO_TEXT_SPACING = 35
FONT = "UI\\Font\\FreeSans.ttf"
FONT_SIZE = 24

runs = nil
mapId = nil

onStop = function()
    loadProfile("_temp")
    deleteProfile("_temp")
end

prepareGhost(0, GHOST_VARIANTS[2])
prepareGhost(1, GHOST_VARIANTS[1])

-- prepare settings
if contains(listProfiles(), "_temp") then
    deleteProfile("_temp")
end
-- save settings in order to not permanently overwrite anything
saveProfile("_temp")

defaultSt("Offline_Game_Mods.video_capture")
setSt("Offline_Game_Mods.video_capture.extra_seconds", EXTRA_SECONDS)
setSt("Offline_Game_Mods.video_capture.crf", CRF)
setSt("Offline_Game_Mods.video_capture.preset", PRESET)
setSt("Offline_Game_Mods.video_capture.batch_size", BATCH_SIZE)
setSt("Offline_Game_Mods.video_capture.batch_count", BATCH_COUNT)
setSt("Offline_Game_Mods.video_capture.capture_audio", CAPTURE_AUDIO)
setSt("Offline_Game_Mods.video_capture.merge_audio_to_video", MERGE_AUDIO_TO_VIDEO)

setSt("Offline_Game_Mods.recording_and_replay.loop_ghosts", false)

defaultSt("Appearance.player.ghost_color")
setSt("Appearance.player.ghost_opacity", GHOST_OPACITY)
setSt("Appearance.player.ghost_in_front_of_trail", true)
if GHOST_DISABLE_GRAPPLES then
    setSt("Appearance.grapple.local_only", true)
    setSt("Appearance.grapple.ghost_opacity", 0)
end

setSt("Performance.particles.disable_remote_players_afterimages", true)

-- request runs
mapId = get("Velo.mapId")
runs = await(requestMapCategoryRuns(mapId, CATEGORY, 0, 0, 3))

-- download runs
requests = {}
for i, run in ipairs(runs) do
    requests[i] = download(run.id, "_temp" .. tostring(i))
end

for i, request in ipairs(requests) do
    await(request)
end

-- initiate capture
setGhost("_temp3", 0)
setGhost("_temp2", 1)
capture("_temp1", getMapName(runs[1].mapId))
deleteRec("_temp1")
deleteRec("_temp2")
deleteRec("_temp3")

-- prepare draw
function timeToStr(time)
    millis = tostring(time % 1000)
    seconds = tostring(time // 1000)
    while string.len(millis) < 3 do
        millis = "0" .. millis
    end
    return seconds .. "s " .. millis .. "ms"
end

height = get("Velo.screenHeight")

heads = {
    "#1 " .. getPlayerName(runs[1].playerId),
    "#2 " .. getPlayerName(runs[2].playerId),
    "#3 " .. getPlayerName(runs[3].playerId)
}

maxWidth = measureText(heads[1], FONT, FONT_SIZE).x
maxWidth = math.max(maxWidth, measureText(heads[2], FONT, FONT_SIZE).x)
maxWidth = math.max(maxWidth, measureText(heads[3], FONT, FONT_SIZE).x)

tails = {
    " - " .. timeToStr(runs[1].runTime),
    " - " .. timeToStr(runs[2].runTime),
    " - " .. timeToStr(runs[3].runTime)
}

function draw(text, color, offsetX, offsetY, opacity)
    color = Color:new(color.r, color.g, color.b, opacity * 255)
    drawText(
        text,
        Vector2:new(INFO_TEXT_OFFSET + offsetX, height - INFO_TEXT_OFFSET - offsetY),
        Vector2:new(0, 0),
        Vector2:new(0, 1),
        1,
        0,
        FONT, FONT_SIZE,
        true,
        color
    )
end

timer = 0
opacity = 1

onPostDraw = function()
    local delta = get("Velo.deltaSec")
    timer = timer + delta
    if timer >= INFO_TEXT_DURATION then
        opacity = math.max(opacity - delta, 0)
    end

    for i = 1, 3 do
        draw(heads[i], TOP_COLORS[i], 0, (3 - i) * INFO_TEXT_SPACING, opacity)
        draw(tails[i], TOP_COLORS[i], maxWidth, (3 - i) * INFO_TEXT_SPACING, opacity)
    end

    if not get("Velo.isPlaybackRunning") then
        exit()
    end
end