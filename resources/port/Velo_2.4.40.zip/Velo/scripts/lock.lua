-- lock demo
-- usage:
-- "lock" to start the script
-- "lock.add [field] [value]" to lock a field to some value
-- "lock.remove [field]" to remove a lock
-- "lock.list" to list all locks
-- "lock.clear" to clear all locks

locks = {}

cmds["add"] = function(field, value)
    locks[field] = value
end

cmds["remove"] = function(field)
    locks[field] = nil
end

cmds["list"] = function()
    for f, v in pairs(locks) do
        echo(f .. ": " .. tostring(v))
    end
end

cmds["clear"] = function()
    locks = {}
end

onPostUpdate = function()
    if not get("Velo.isIngame") then
        return
    end
    for f, v in pairs(locks) do
        set(f, v)
    end
end