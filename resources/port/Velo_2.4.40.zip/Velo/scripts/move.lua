-- move demo
-- offsets the player by the specified x- and y-coordinates

-- usage: `move [x] [y]`

offset = Vector2:new(arg[1], arg[2])
position = get("Player.actor.position")
set("Player.actor.position", position + offset)