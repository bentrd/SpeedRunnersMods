-- Velo library providing some utilities
-- do not modify or your changes will be overwritten by the next update

-- key modifiers
MOD_SHIFT = 0x100
MOD_CTRL = 0x200
MOD_CONTROLLER = 0x400
MOD_ANY = 0x800

-- mouse buttons
M_LEFT = 1
M_RIGHT = 2
M_MIDDLE = 4
M_X1 = 5
M_X2 = 6

-- controller buttons
GP_A = MOD_CONTROLLER | 0
GP_B = MOD_CONTROLLER | 1
GP_X = MOD_CONTROLLER | 2
GP_Y = MOD_CONTROLLER | 3
GP_LEFT_SHOULDER = MOD_CONTROLLER | 4 
GP_RIGHT_SHOULDER = MOD_CONTROLLER | 5
GP_LEFT_STICK = MOD_CONTROLLER | 6
GP_RIGHT_STICK = MOD_CONTROLLER | 7
GP_START = MOD_CONTROLLER | 8
GP_BACK = MOD_CONTROLLER | 9
GP_BIG_BUTTON = MOD_CONTROLLER | 10
GP_TRIGGER_LEFT = MOD_CONTROLLER | 11
GP_TRIGGER_RIGHT = MOD_CONTROLLER | 12
GP_DPAD_LEFT = MOD_CONTROLLER | 13
GP_DPAD_RIGHT = MOD_CONTROLLER | 14
GP_DPAD_UP = MOD_CONTROLLER | 15
GP_DPAD_DOWN = MOD_CONTROLLER | 16

-- collision bits
COL_BIT_ENVIRONMENT = 1 << 24
COL_BIT_FALL_TILE = 1 << 20
COL_BIT_ENVIRONMENT_DYNAMIC = 1 << 21
COL_BIT_PLAYER_TRIGGER = 1 << 16
COL_BIT_LEAVES = 1 << 17
COL_BIT_AI_VOLUME = 1 << 18
COL_BIT_DECO = 1 << 19
COL_BIT_SUPER_BOOST = 1 << 12
COL_BIT_BOOSTA_COKE = 1 << 13
COL_BIT_BOSS = 1 << 8
COL_BIT_LETHAL_OBSTACLE = 1 << 9
COL_BIT_FIREBALL = 1 << 10
COL_BIT_DROPPED_ENTITY = 1 << 11
COL_BIT_TILE = 1 << 4
COL_BIT_FALL_BLOCK = 1 << 5
COL_BIT_SPECIAL_TILE = 1 << 6
COL_BIT_TRIGGER = 1 << 0
COL_BIT_CHECKPOINT = 1 << 1
COL_BIT_PLAYER_1 = 1 << 28
COL_BIT_PLAYER_2 = 1 << 29
COL_BIT_PLAYER_3 = 1 << 30
COL_BIT_PLAYER_4 = 1 << 31
COL_BIT_PLAYER_5 = 1 << 25
COL_BIT_PLAYER_6 = 1 << 26
COL_BIT_PLAYER_7 = 1 << 27
COL_BIT_PLAYER_8 = 1 << 22
COL_BIT_PLAYER_9 = 1 << 23
COL_BIT_PLAYER_10 = 1 << 14
COL_BIT_PLAYER_11 = 1 << 15
COL_BIT_PLAYER_12 = 1 << 7
COL_BIT_PLAYER_13 = 1 << 2
COL_BIT_PLAYER_14 = 1 << 3
COL_BIT_PLAYER_15 = 1 << 8
COL_BIT_PLAYER_16 = 1 << 5
COL_BIT_ALL = 0xFFFFFFFF

-- slot types
SLOT_TYPE_UNKNOWN = 0;
SLOT_TYPE_CLOSED = 1;
SLOT_TYPE_LOCAL = 2;
SLOT_TYPE_FRIEND = 3;
SLOT_TYPE_PUBLIC = 4;

-- slot states
STATE_UNKNOWN = 0;
STATE_SEARCHING = 1;
STATE_CONNECTED = 2;
STATE_READY = 3;

-- playback types
PB_NONE = -1
PB_GHOST = 0
PB_REPLAY = 1
PB_REPLAY_EXACT = 2
PB_VERIFY = 3
PB_CAPTURE = 4

-- run categories
NEW_LAP = 0
ONE_LAP = 1
NEW_LAP_SKIP = 2
ONE_LAP_SKIP = 3
ANY_PERC = 4
HUNDRED_PERC = 5
EVENT = 6

-- official map IDs
MAP_METRO = 0
MAP_SS_ROYALE = 1
MAP_MANSION = 2
MAP_PLAZA = 3
MAP_FACTORY = 4
MAP_THEME_PARK = 5
MAP_POWERPLANT = 6
MAP_SILO = 7
MAP_LIBRARY = 8
MAP_NIGHTCLUB = 9
MAP_ZOO = 10
MAP_SWIFT_PEAKS = 11
MAP_CASINO = 12
MAP_FESTIVAL = 13
MAP_RESORT = 14
MAP_AIRPORT = 15
MAP_LABORATORY = 16

-- theme IDs
THEME_METRO = 0
THEME_SS_ROYALE = 1
THEME_MANSION = 2
THEME_PLAZA = 3
THEME_FACTORY = 4
THEME_THEME_PARK = 5
THEME_POWERPLANT = 6
THEME_SILO = 7
THEME_LIBRARY = 8
THEME_NIGHTCLUB = 9
THEME_ZOO = 10
THEME_SWIFT_PEAKS = 11
THEME_CASINO = 12
THEME_FESTIVAL = 13
THEME_RESORT = 14
THEME_AIRPORT = 15
THEME_LABORATORY = 16
THEME_PROTOTYPE = 17
THEME_ALLEY = 18

-- number of Velo curated maps
VELO_CURATED_COUNT = 91

function isOfficial(mapId)
    return mapId <= 16
end

function isOldRWS(mapId)
    return 
        mapId == 19 or
        mapId == 21 or
        mapId == 27 or
        mapId == 29 or
        mapId == 39 or
        mapId == 41 or
        mapId == 42 or
        mapId == 85 or
        mapId == 86 or
        mapId == 87 or
        (mapId >= 45 and mapId <= 54)
end

function isRWS(mapId)
    return
        ((mapId >= 17 and mapId <= 44) or
        (mapId >= 85 and mapId < VELO_CURATED_COUNT)) and
        not isOldRWS(mapId)
end

function isOrigins(mapId)
    return mapId >= 55 and mapId <= 84
end

function isVeloCurated(mapId)
    return mapId < VELO_CURATED_COUNT
end

function hasSkip(mapId)
    return
        mapId == 0 or
        mapId == 1 or
        mapId == 3 or
        mapId == 4 or
        mapId == 5 or
        mapId == 8 or
        mapId == 10 or
        mapId == 13 or
        mapId == 14 or
        mapId == 20 or
        mapId == 23 or
        mapId == 24 or
        mapId == 26 or
        mapId == 29 or
        mapId == 39 or
        mapId == 44 or
        mapId == 50 or
        mapId == 51
end

function has100perc(mapId)
    return
        mapId == 55 or
        mapId == 56 or
        mapId == 57 or
        mapId == 58 or
        mapId == 60 or
        mapId == 61 or
        mapId == 62 or
        mapId == 63 or
        mapId == 64 or
        mapId == 66 or
        mapId == 67 or
        mapId == 68 or
        mapId == 69 or
        mapId == 70 or
        mapId == 71
end

TICKS_PER_SECOND = 10000000

function tileToWorld(pos)
    return 16 * pos
end

function worldToTile(pos)
    return Vector2:new(math.floor(pos.x / 16), math.floor(pos.y / 16))
end

-- check if array contains value
function contains(arr, value)
    for i = 1, #arr do
        if arr[i] == value then 
            return true
        end
    end
    return false
end

-- two-dimensional vector
Vector2 = { mt = {} }

Vector2.mt.__add = function(v1, v2)
    return Vector2:new(v1.x + v2.x, v1.y + v2.y) 
end

Vector2.mt.__sub = function(v1, v2) 
    return Vector2:new(v1.x - v2.x, v1.y - v2.y) 
end

Vector2.mt.__unm = function(v) 
    return Vector2:new(-v.x, -v.y) 
end

Vector2.mt.__mul = function(x1, x2)
    if (type(x1) == "number") then
        return Vector2:new(x1 * x2.x, x1 * x2.y) -- scalar multiplication (left)
    elseif (type(x2) == "number") then
        return Vector2:new(x1.x * x2, x1.y * x2) -- scalar multiplication (right)
    else
        return Vector2:new(x1.x * x2.x, x1.y * x2.y) -- element-wise multiplication
    end
end

Vector2.mt.__div = function(x1, x2)
    if (type(x2) == "number") then
        return Vector2:new(x1.x / x2, x1.y / x2) -- scalar division (right)
    else
        return Vector2:new(x1.x / x2.x, x1.y / x2.y) -- element-wise division
    end
end

Vector2.mt.__tostring = function(v) 
    return "(" .. v.x .. ", " .. v.y .. ")" 
end

Vector2.mt.__index = Vector2

function Vector2:length(v)
    return math.sqrt(v.x * v.x + v.y * v.y)
end

function Vector2:new(_x, _y)
    return setmetatable({
        x = _x or 0, 
        y = _y or 0
    }, Vector2.mt)
end

-- RGBA color
Color = { mt = {} }

Color.mt.__add = function(c1, c2)
    return Color:new(c1.r + c2.r, c1.g + c2.g, c1.b + c2.b, c1.a + c2.a)
end

Color.mt.__sub = function(c1, c2)
    return Color:new(c1.r - c2.r, c1.g - c2.g, c1.b - c2.b, c1.a - c2.a)
end

Color.mt.__mul = function(x1, x2)
    if (type(x1) == "number") then
        return Color:new(x1 * x2.r, x1 * x2.g, x1 * x2.b, x1 * x2.a) -- scalar multiplication (left)
    elseif (type(x2) == "number") then
        return Color:new(x1.r * x2, x1.g * x2, x1.b * x2, x1.a * x2) -- scalar multiplication (right)
    else
        return Color:new(c1.r * c2.r / 255, c1.g * c2.g / 255, c1.b * c2.b / 255, c1.a * c2.a / 255) -- element-wise multiplication
    end
end

Color.mt.__div = function(x1, x2)
    return Color:new(x1.r / x2, x1.g / x2, x1.b / x2, x1.a / x2) -- scalar division (right)
end

Color.mt.__tostring = function(v) 
    return "(" .. v.r .. ", " .. v.g .. ", " .. v.b .. ", " .. v.a .. ")" 
end

Color.mt.__index = Color

function Color:new(_r, _g, _b, _a)
    return setmetatable({
        r = _r or 0, 
        g = _g or 0,
        b = _b or 0,
        a = _a or 255
    }, Color.mt)
end

function Color:mix(c1, c2, r)
    return (1 - r) * c1 + r * c2
end

-- toggle setting
Toggle = {}

function Toggle:new(
    _key, -- number
    _enabled -- boolean
)
    return {
        key = _key or 0x97, -- Windows virtual key code (0x97 is unassigned)
        enabled = _enabled or false
    }
end

-- color transition setting
ColorTransition = {}

function ColorTransition:new(
    _period, -- number
    _offset, -- number
    _discrete, -- boolean
    _colors -- Color array
)
    return {
        period = _period,
        offset = _offset,
        discrete = _discrete,
        colors = _colors
    }
end

-- input box setting
InputBox = {}

function InputBox:new(
    _position, -- Vector2
    _size, -- Vector2
    _text -- string
)
    return {
        position = _position,
        size = _size,
        text = _text
    }
end
